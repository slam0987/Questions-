// script.js
function calculateAge() {
    var birthdate = new Date(document.getElementById("birthdate").value);
    var today = new Date();
    var age = today.getFullYear() - birthdate.getFullYear();
    var monthDifference = today.getMonth() - birthdate.getMonth();

    if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthdate.getDate())) {
        age--;
    }

    if (!isNaN(age) && age >= 0) {
        document.getElementById("result").innerHTML = "عمرك هو: " + age + " سنة";
    } else {
        document.getElementById("result").innerHTML = "الرجاء إدخال تاريخ ميلاد صالح";
    }
}
